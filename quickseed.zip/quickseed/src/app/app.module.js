"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/** Core Modules */
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var http_1 = require("@angular/http");
/** Root Module */
var app_component_1 = require('./app.component');
var app_routing_module_1 = require('./app-routing.module');
/** Other Libraries */
var ng_bootstrap_1 = require('@ng-bootstrap/ng-bootstrap');
/** Smart Components */
var home_component_1 = require('./components/smart/home/home.component');
var profile_component_1 = require('./components/smart/profile/profile.component');
/** Dumb Components */
var footer_component_1 = require('./components/dumb/footer/footer.component');
var menu_component_1 = require('./components/dumb/menu/menu.component');
var profile_card_component_1 = require('./components/dumb/profile-card/profile-card.component');
var profile_status_component_1 = require('./components/dumb/profile-status/profile-status.component');
/** Services */
var user_service_1 = require('./services/user.service');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, app_routing_module_1.AppRoutingModule, http_1.HttpModule, ng_bootstrap_1.NgbModule.forRoot()],
            declarations: [app_component_1.AppComponent, menu_component_1.AppMenuComponent, home_component_1.HomeComponent, profile_component_1.ProfilePageComponent, footer_component_1.FooterComponent,
                profile_card_component_1.ProfileCardComponent, profile_status_component_1.ProfileStatusComponent],
            providers: [user_service_1.UserService],
            bootstrap: [app_component_1.AppComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map