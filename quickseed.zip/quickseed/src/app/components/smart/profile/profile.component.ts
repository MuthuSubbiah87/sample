import { Component, OnInit } from '@angular/core';
import { User }        from '../../../models/user.model';
import { UserService } from '../../../services/user.service';

@Component({
  moduleId: module.id,
  selector: 'profile-page',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfilePageComponent implements OnInit {
    public users: User[];
    public errorMessage: any;


    constructor(private userService: UserService) { }

    ngOnInit() {
        this.userService.getUsers().subscribe(
            users => this.users = users,
            error => this.errorMessage = <any>error);
    }

    
      
}
