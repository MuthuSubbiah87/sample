import { Component, Input, OnInit } from '@angular/core';
import { User } from '../../../models/user.model';

@Component({
    moduleId: module.id,
    selector: 'profile-status',
    templateUrl: './profile-status.component.html',
    styleUrls: ['./profile-status.component.css']
})

export class ProfileStatusComponent implements OnInit {

    

   
    ngOnInit(): void {
            throw new Error('Method not implemented.');
    }

   
}
