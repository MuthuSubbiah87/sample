import { Component, Input, Output, EventEmitter } from '@angular/core';
import { User } from '../../../models/user.model';


@Component({
    moduleId: module.id,
    selector: 'profile-card',
    templateUrl: './profile-card.component.html',
    styleUrls: ['./profile-card.component.css']
})

export class ProfileCardComponent {

    @Input() user: User;

    @Output() onCardSelectEvent: EventEmitter<User> = new EventEmitter<User>();

    selectUser() {
        this.onCardSelectEvent.emit(this.user);
    }

}