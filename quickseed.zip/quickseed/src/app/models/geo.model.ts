export class Geo {
    lat: number;
    lng: number;
}