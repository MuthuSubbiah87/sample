import {Address} from './address.model'
import {Company} from './company.model'
import {Geo} from './geo.model'

export class User {
    id: number;
    name: string;
    username: string;
    email: string;
    phone: number;
    website: string;
    address: Address;
}