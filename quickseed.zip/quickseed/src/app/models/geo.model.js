"use strict";
var Geo = (function () {
    function Geo() {
    }
    return Geo;
}());
exports.Geo = Geo;
//# sourceMappingURL=geo.model.js.map