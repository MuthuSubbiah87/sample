"use strict";
var Address = (function () {
    function Address() {
    }
    return Address;
}());
exports.Address = Address;
//# sourceMappingURL=address.model.js.map