"use strict";
var Company = (function () {
    function Company() {
    }
    return Company;
}());
exports.Company = Company;
//# sourceMappingURL=company.model.js.map