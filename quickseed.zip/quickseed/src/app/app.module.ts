/** Core Modules */
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule} from "@angular/http";

/** Root Module */
import { AppComponent }  from './app.component';
import { AppRoutingModule }  from './app-routing.module';

/** Other Libraries */
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

/** Smart Components */
import { HomeComponent }  from './components/smart/home/home.component';
import { ProfilePageComponent }  from './components/smart/profile/profile.component';

/** Dumb Components */
import { FooterComponent }  from './components/dumb/footer/footer.component';
import { AppMenuComponent }  from './components/dumb/menu/menu.component';
import { ProfileCardComponent } from './components/dumb/profile-card/profile-card.component';
import { ProfileStatusComponent } from './components/dumb/profile-status/profile-status.component';

/** Services */
import { UserService }  from './services/user.service';

@NgModule({
  imports:      [ BrowserModule, AppRoutingModule, HttpModule, NgbModule.forRoot() ],
  declarations: [ AppComponent, AppMenuComponent, HomeComponent, ProfilePageComponent, FooterComponent,
   ProfileCardComponent, ProfileStatusComponent],
  providers: [ UserService ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
