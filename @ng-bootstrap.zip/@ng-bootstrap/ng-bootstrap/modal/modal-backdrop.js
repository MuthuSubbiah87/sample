import { Component } from '@angular/core';
var NgbModalBackdrop = (function () {
    function NgbModalBackdrop() {
    }
    return NgbModalBackdrop;
}());
export { NgbModalBackdrop };
NgbModalBackdrop.decorators = [
    { type: Component, args: [{ selector: 'ngb-modal-backdrop', template: '', host: { 'class': 'modal-backdrop fade show' } },] },
];
/** @nocollapse */
NgbModalBackdrop.ctorParameters = function () { return []; };
//# sourceMappingURL=modal-backdrop.js.map