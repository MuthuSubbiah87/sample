import { ModuleWithProviders } from '@angular/core';
export { NgbAlert } from './alert';
export { NgbAlertConfig } from './alert-config';
export declare class NgbAlertModule {
    static forRoot(): ModuleWithProviders;
}
