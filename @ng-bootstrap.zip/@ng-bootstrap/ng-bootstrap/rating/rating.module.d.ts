import { ModuleWithProviders } from '@angular/core';
export { NgbRating } from './rating';
export { NgbRatingConfig } from './rating-config';
export declare class NgbRatingModule {
    static forRoot(): ModuleWithProviders;
}
