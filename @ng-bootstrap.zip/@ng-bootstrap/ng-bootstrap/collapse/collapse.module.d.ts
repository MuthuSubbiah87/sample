import { ModuleWithProviders } from '@angular/core';
export { NgbCollapse } from './collapse';
export declare class NgbCollapseModule {
    static forRoot(): ModuleWithProviders;
}
