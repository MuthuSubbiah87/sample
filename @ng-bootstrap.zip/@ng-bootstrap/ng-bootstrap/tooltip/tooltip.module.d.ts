import { ModuleWithProviders } from '@angular/core';
export { NgbTooltipConfig } from './tooltip-config';
export { NgbTooltip } from './tooltip';
export declare class NgbTooltipModule {
    static forRoot(): ModuleWithProviders;
}
