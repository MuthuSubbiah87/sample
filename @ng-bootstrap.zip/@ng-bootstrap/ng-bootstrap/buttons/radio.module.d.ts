import { ModuleWithProviders } from '@angular/core';
export { NgbRadio, NgbActiveLabel, NgbRadioGroup } from './radio';
export declare class NgbButtonsModule {
    static forRoot(): ModuleWithProviders;
}
