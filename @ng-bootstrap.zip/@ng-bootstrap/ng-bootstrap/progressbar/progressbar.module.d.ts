import { ModuleWithProviders } from '@angular/core';
export { NgbProgressbar } from './progressbar';
export { NgbProgressbarConfig } from './progressbar-config';
export declare class NgbProgressbarModule {
    static forRoot(): ModuleWithProviders;
}
