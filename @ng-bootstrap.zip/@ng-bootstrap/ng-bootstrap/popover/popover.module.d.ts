import { ModuleWithProviders } from '@angular/core';
export { NgbPopover } from './popover';
export { NgbPopoverConfig } from './popover-config';
export declare class NgbPopoverModule {
    static forRoot(): ModuleWithProviders;
}
