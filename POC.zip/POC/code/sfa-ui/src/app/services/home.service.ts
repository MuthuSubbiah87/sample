import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { APIRoutes } from '../constants/APIRoutes';
import { Account } from '../models/Account';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: HttpClient, private authenticationService: AuthenticationService) { }

  public fetchAllAccounts() {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.get(`${environment.baseUrl}${APIRoutes.fetchAllAccounts}`, { headers });
  }

  public saveAccount(account: Account) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.put(`${environment.baseUrl}${APIRoutes.saveAccount}`, account, { headers });
  }

  public fetchAccount(accountId: string) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.get(`${environment.baseUrl}${APIRoutes.getAccount}${accountId}`, { headers });
  }

  public updateAccount(account: Account) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.post(`${environment.baseUrl}${APIRoutes.updateAccount}`, account, { headers });
  }

  public deleteAccount(accountId: string) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.delete(`${environment.baseUrl}${APIRoutes.deleteAccount}${accountId}`, { headers });
  }


}

