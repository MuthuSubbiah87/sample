import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { APIRoutes } from 'src/app/constants/APIRoutes';
import { User } from '../models/User';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  public loggedInUser: User;
  public authToken: string;

  constructor(private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  public login(username: string, password: string) {
    this.authToken = 'Basic ' + btoa(username + ":" + password);
    localStorage.setItem('authToken', this.authToken);
    let headers = new HttpHeaders({ Authorization: this.authToken, username: username });
    return this.http.get(`${environment.baseUrl}${APIRoutes.login}`, { headers, responseType: 'json' });
  }

  public fetchUserDetailsFromLocalStorage() {
    let userObjStr = localStorage.getItem('user');
    let userObj = JSON.parse(userObjStr ? userObjStr : "{}");
    this.loggedInUser = <User>userObj;
    return this.loggedInUser;
  }

  public getAuthTokenForUser() {
    let token = localStorage.getItem('authToken');
    const headers = new HttpHeaders({ 'Authorization': token ? token : "" });
    return headers;
  }

  public logout() {
    localStorage.clear();
  }

  public handleUnauthorizeError(error: any) {
    if (error.error.message && error.error.status) {
      this.toastr.error(error.error.message);
    } else if (error.error.errorCode && error.error.errorDescription) {
      this.toastr.error(error.error.errorCode, error.error.errorDescription);
    }
  }


}
