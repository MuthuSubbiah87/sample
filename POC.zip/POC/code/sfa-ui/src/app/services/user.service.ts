import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { APIRoutes } from '../constants/APIRoutes';
import { User } from '../models/User';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private authenticationService: AuthenticationService) { }

  public fetchUsers() {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.get(`${environment.baseUrl}${APIRoutes.fetchUsers}`, { headers, responseType: 'json' });
  }

  public fetchUser(userId: string) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.get(`${environment.baseUrl}${APIRoutes.fetchUser}${userId}`, { headers, responseType: 'json' });
  }

  public updateUser(user: User) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.post(`${environment.baseUrl}${APIRoutes.updateUser}`, user, { headers, responseType: 'json' });
  }

  public saveUser(user: User) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.put(`${environment.baseUrl}${APIRoutes.saveUser}`, user, { headers, responseType: 'json' });
  }

  public deleteUser(userId: string) {
    let headers = this.authenticationService.getAuthTokenForUser();
    return this.http.delete(`${environment.baseUrl}${APIRoutes.deleteUser}${userId}`, { headers, responseType: 'json' });
  }

}
