export class Note {
    public _id: string;
    public accountId: string;
    public note: string;
    public createdDate: Date;

    constructor(note:string){
        this.note = note;
        this.createdDate = new Date;
    }
}