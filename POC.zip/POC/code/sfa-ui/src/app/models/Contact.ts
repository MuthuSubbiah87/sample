export class Contact {
    public _id: string;
    public accountId: string;
    public name: string;
    public email: string;
    public primaryContact:boolean;
    public phone: number;
}

