import { Contact } from "./Contact";
import { Note } from "./Note";

export class Account {
    public _id: string;
    public accountName: string;
    public address: string;
    public url: string;
    public ceo:string;
    public employeeCount:number;
    public contacts:Contact[];
    public notes:Note[];
}

