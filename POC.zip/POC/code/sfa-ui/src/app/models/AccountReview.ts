import { Contact } from "./Contact";
import { ContactReview } from "./ContactReview";
import { Entry } from "./Entry";
import { Note } from "./Note";
import { NoteReview } from "./NoteReview";

export class AccountReview {
    public entries: Entry[];
    public contactReviews: ContactReview[];
    public noteReviews: NoteReview[];
    public removedContacts: Contact[];
    public addedContacts: Contact[];
    public removedNotes: Note[];
    public addedNotes: Note[];

    constructor(){
        this.entries = [];
        this.contactReviews = [];
        this.noteReviews = [];
        this.removedContacts = [];
        this.addedContacts = [];
        this.removedNotes = [];
        this.addedNotes = [];
         
    }
}