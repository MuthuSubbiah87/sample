import { Entry } from "./Entry";
import { Note } from "./Note";

export class NoteReview {
    public entries: Entry[];
    
    constructor(){
        this.entries = [];

    }
}