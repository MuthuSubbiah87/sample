export class Entry {
    public fieldName: any;
    public prevValue: any;
    public currValue: any;

    constructor(fieldName: any,prevValue: any,currValue: any){
        this.fieldName = fieldName;
        this.prevValue = prevValue;
        this.currValue = currValue;
    }
}