export class User {
    public _id: string;
    public firstName: string;
    public lastName: string;
    public userName: string;
    public role:string;
    public email:string;
    public password:string;
    public active:boolean;
}