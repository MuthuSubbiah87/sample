import { Contact } from "./Contact";
import { Entry } from "./Entry";

export class ContactReview {
    public entries: Entry[];
    
    constructor(){
        this.entries = []
    }
}