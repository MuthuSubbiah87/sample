import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations'
import { NgxSpinnerModule } from "ngx-spinner";

import { ToastrModule} from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/pages/home/home.component';
import { UserComponent } from './components/pages/user/user.component';
import { LoginComponent } from './components/pages/login/login.component';
import { AuthenticationService } from './services/authentication.service';
import { HomeService } from './services/home.service';
import { UserService } from './services/user.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { NavbarComponent } from './components/dumb/navbar/navbar.component';
import { FooterComponent } from './components/dumb/footer/footer.component';
import { ErrorComponent } from './components/pages/error/error.component';
import { ProfileComponent } from './components/pages/profile/profile.component';
import { HeaderComponent } from './components/dumb/header/header.component';
import { UserModelComponent } from './components/dumb/user-model/user-model.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AccountDetailsComponent } from './components/pages/account-details/account-details.component';
import { FilterByPipe } from './pipes/filter-by.pipe';
import { PrettyPrintPipe } from './pipes/pretty-print.pipe';
import { SearchPipe } from './pipes/search.pipe'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserComponent,
    LoginComponent,
    NavbarComponent,
    FooterComponent,
    ErrorComponent,
    ProfileComponent,
    HeaderComponent,
    UserModelComponent,
    AccountDetailsComponent,
    FilterByPipe,
    PrettyPrintPipe,
    SearchPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgxSpinnerModule,
    NgbModule,
    ReactiveFormsModule
  ],
  providers: [AuthenticationService,HomeService,UserService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
