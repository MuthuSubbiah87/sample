import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import { AccountDetailsComponent } from './components/pages/account-details/account-details.component';
import { HomeComponent } from './components/pages/home/home.component';
import { LoginComponent } from './components/pages/login/login.component';
import { ProfileComponent } from './components/pages/profile/profile.component';
import { UserComponent } from './components/pages/user/user.component';


const routes: Routes = [
  {path:"", component:LoginComponent, pathMatch:"full"},
  {path:"login", component:LoginComponent},
  {path:"home", component:HomeComponent},
  {path:"user", component:UserComponent},
  {path:"profile", component:ProfileComponent},
  {path:"account/:_id", component:AccountDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),],
  exports: [RouterModule]
})
export class AppRoutingModule { }
