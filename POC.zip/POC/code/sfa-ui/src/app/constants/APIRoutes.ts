export const APIRoutes = {
  //Authentication 
  login: '/user/login',
  logout: '/user/logout',

  //User
  fetchUsers: '/user/users',
  fetchUser: '/user/',
  saveUser: '/user/save',
  deleteUser: '/user/delete/',
  updateUser: '/user/update',

  //Account
  fetchAllAccounts: '/account/all',
  saveAccount: '/account/add',
  deleteAccount: '/account/delete/',
  getAccount: '/account/',
  updateAccount: '/account/update',

};