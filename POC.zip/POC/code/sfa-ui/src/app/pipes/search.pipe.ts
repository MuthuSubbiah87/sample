import { Pipe, PipeTransform } from '@angular/core';
import { Account } from '../models/Account';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(items: Account[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLocaleLowerCase();

    return items.filter(it => {
      return it.accountName.toLocaleLowerCase().includes(searchText) || 
      it.url.toLocaleLowerCase().includes(searchText) ||
      it.address.toLocaleLowerCase().includes(searchText) 
    });
  }

}
