import { Pipe, PipeTransform } from '@angular/core';
import { Contact } from '../models/Contact';

@Pipe({
  name: 'filterBy'
})
export class FilterByPipe implements PipeTransform {

  transform(contacts: Contact[], value:any) : any {
    return contacts.filter((e) => {
      return (e.primaryContact == true);
    });
  }

}
