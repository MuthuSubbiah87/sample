import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Account } from 'src/app/models/Account';
import { User } from 'src/app/models/User';
import { FilterByPipe } from 'src/app/pipes/filter-by.pipe';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { HomeService } from 'src/app/services/home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private homeService: HomeService, private router: Router,
    private authenticationService: AuthenticationService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService) { }

  public accounts: Account[];
  public newAccount: Account;
  public editAccountId: string;
  public isNewAccountAdded: boolean = false;
  public filterInput: string = '';
  loggedInUser:User;
  ngOnInit(): void {
    this.loggedInUser = this.authenticationService.fetchUserDetailsFromLocalStorage();
    if (Object.keys(this.loggedInUser).length === 0){
      this.router.navigateByUrl('/login');
    }
    this.newAccount = new Account();
    this.spinner.show();
    this.homeService.fetchAllAccounts().subscribe(dataResp => {
      this.accounts = <Account[]>dataResp;
      this.spinner.hide();
    }, (error) => {
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error.error);
    })
  }

  addNewAccount() {
    this.newAccount.accountName='';
    this.newAccount.address='';
    this.isNewAccountAdded = true;
  }

  removeNewAccount() {
    this.isNewAccountAdded = false;
  }

  validateAccountBeforeSave() {
    let fields: string[] = [];
    let isValidAccount: boolean = true;
    if (!this.newAccount.accountName && this.newAccount.accountName == '') {
      fields.push('Madatory fields require.');
      isValidAccount = false;
    } else if(!this.newAccount.accountName.match("^[a-zA-Z0-9]*$")){
      fields.push('Account Name must contain alphanumric.');
      isValidAccount = false;
    }
    if (!this.newAccount.address && this.newAccount.address == '') {
      fields.push('Madatory fields require.');
      isValidAccount = false;
    }else if(!this.newAccount.address.match("^[a-zA-Z0-9]*$")){
      fields.push('Account Name must contain alphanumric.');
      isValidAccount = false;
    }
    let setFields = [...new Set(fields)];
    if (!isValidAccount){
      this.toastr.warning(setFields.join("</br>"), '',{ enableHtml: true});
    }
    return isValidAccount;
  }

  saveNewAccount() {
    if (this.validateAccountBeforeSave()) {
      this.spinner.show();
      this.homeService.saveAccount(this.newAccount).subscribe((data) => {
        let savedData: Account = <Account>data;
        this.spinner.hide();
        this.toastr.success(`Account for saved successfully.`, "Success");
        this.router.navigateByUrl('/account/' + savedData._id);
      }, (error) => {
        this.spinner.hide();
        this.authenticationService.handleUnauthorizeError(error);
      });
    }

  }

  deleteAccount(accountId: string) {
    this.spinner.show();
    this.homeService.deleteAccount(accountId).subscribe((data) => {
      this.spinner.hide();
      this.toastr.success(`Account deleted successfully.`, "Success");
      this.ngOnInit();
    }, (error) => {
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    });
  }


}
