import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { User } from 'src/app/models/User';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  logedInUserProfile:User;

  constructor(private authenticationService:AuthenticationService, 
    private router:Router, 
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private userService:UserService,
    ) { }

  ngOnInit(): void {
    this.spinner.show();
    this.logedInUserProfile = this.authenticationService.fetchUserDetailsFromLocalStorage();
    if (Object.keys(this.logedInUserProfile).length === 0){
      this.router.navigateByUrl('/login');
    }
    this.spinner.hide();
  }

  public updateUser(){
    this.spinner.show();
    this.userService.updateUser(this.logedInUserProfile).subscribe((data)=>{
      this.toastr.success(`User profile for updated successfully.}.`,"Success")
      this.spinner.hide();
    },(error)=>{
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    })
  }

}
