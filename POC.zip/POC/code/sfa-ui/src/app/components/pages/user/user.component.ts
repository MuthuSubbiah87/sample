import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { User } from 'src/app/models/User';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService:UserService,
    private spinner: NgxSpinnerService,
    private authenticationService:AuthenticationService,
    private modalService: NgbModal,
    private toastr: ToastrService,
    private router:Router, ) { }
    public newUser:User = new User();

  public usersList:User[];
  //public user:User = new User();
  public closeResult = '';

  isNewUserAdded:boolean = false;

  logedInUserProfile:User;
  ngOnInit(): void {
    this.logedInUserProfile = this.authenticationService.fetchUserDetailsFromLocalStorage();
    if (Object.keys(this.logedInUserProfile).length === 0){
      this.router.navigateByUrl('/login');
    }
    this.fetchAllUsers();
  }

  public fetchAllUsers(){
    this.spinner.show();
    this.userService.fetchUsers().subscribe((data)=>{
      this.usersList= <User[]> data;
      this.spinner.hide();
    },(error)=>{
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    })
  }

  addNewUser() {
    this.newUser.firstName='';
    this.newUser.lastName='';
    this.newUser.email='';
    this.newUser.role='SALES_REP';
    this.newUser.userName='';
    this.newUser.password='';
    this.isNewUserAdded = true;
  }

  removeNewUser() {
    this.isNewUserAdded = false;
    this.newUser.firstName='';
    this.newUser.lastName='';
    this.newUser.email='';
    this.newUser.role='SALES_REP';
    this.newUser.userName='';
    this.newUser.password='';
  }

  public adduser(){
    this.spinner.show();
    this.userService.saveUser(this.newUser).subscribe((resp)=>{
      this.spinner.hide();
      this.toastr.success(`User profile for added successfully.}.`,"Success")
      this.removeNewUser();
      this.fetchAllUsers();
    },(error)=>{
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    });
  }

  open(content:any) {
    this.modalService.open(content, {size: 'lg',ariaLabelledBy: 'modal-basic-title', backdrop: 'static'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteUser(userId:string){
    this.spinner.show();
    this.userService.deleteUser(userId).subscribe((resp)=>{
      this.spinner.hide();
      this.toastr.success(`User deleted successfully.}.`,"Success")
      this.fetchAllUsers();
    },(error)=>{
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    });
  }

  

}
