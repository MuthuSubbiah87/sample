import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Account } from 'src/app/models/Account';
import { AccountReview } from 'src/app/models/AccountReview';
import { Contact } from 'src/app/models/Contact';
import { ContactReview } from 'src/app/models/ContactReview';
import { Entry } from 'src/app/models/Entry';
import { Note } from 'src/app/models/Note';
import { NoteReview } from 'src/app/models/NoteReview';
import { User } from 'src/app/models/User';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { HomeService } from 'src/app/services/home.service';


@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  constructor(private route: ActivatedRoute, private homeService: HomeService,
    private authenticationService: AuthenticationService,
    private spinner: NgxSpinnerService,
    private modalService: NgbModal,
    private router: Router,
    private toastr: ToastrService) { }

  accountId: string;
  accountDetails: Account = new Account();
  prevAccountDetails: Account;
  activeTab: string = 'profile';
  reviewActiveTab: string = 'account';
  editMode: string;
  noteEditMode: string;
  newNote: Note;
  newContact: Contact;
  closeResult = '';
  accountReview: AccountReview;
  ACCOUNT_OBJ: string = "Account";
  CONTACT_OBJ: string = "Contact";
  NOTE_OBJ: string = "Note";
  fieldsSet: string[];
  loggedInUser: User;
  //fields: string[] = [];



  ngOnInit(): void {
    this.loggedInUser = this.authenticationService.fetchUserDetailsFromLocalStorage();
    if (Object.keys(this.loggedInUser).length === 0) {
      this.router.navigateByUrl('/login');
    }
    this.accountReview = new AccountReview();
    this.newNote = new Note('');
    this.fetchAccountDetails();
  }

  fetchAccountDetails() {
    //this.spinner.show();
    this.route.params.subscribe(params => {
      this.accountId = params['_id'];
      if (this.accountId != 'new') {
        this.spinner.show();
        this.homeService.fetchAccount(this.accountId).subscribe(dataResp => {
          this.spinner.hide();
          this.accountDetails = <Account>dataResp;
          this.prevAccountDetails = JSON.parse(JSON.stringify(this.accountDetails));
        }, (error) => {
          this.spinner.hide();
          this.authenticationService.handleUnauthorizeError(error.error);
        })
      }
    });
  }

  switchTo(tabName: string) {
    this.activeTab = tabName;
  }

  reviewTabswitchTo(tabName: string) {
    this.reviewActiveTab = tabName;
  }

  editContact(contactId: string) {
    this.editMode = contactId;
  }

  editNote(noteId: string) {
    this.noteEditMode = noteId;
  }

  addNoteToAccount() {
    if (this.newNote.note != '') {
      this.newNote.accountId = this.accountDetails._id;
      this.accountDetails.notes.push(this.newNote);
      this.newNote = new Note('');
    } else {
      this.toastr.warning(`Please add note`, "Warning")
    }
  }

  addContactToAccount() {
    this.newContact = new Contact();
    this.newContact.accountId = this.accountDetails._id;
    this.newContact.email = '';
    this.newContact.name = '';
    this.newContact.primaryContact = false;
    this.accountDetails.contacts.push(this.newContact);
  }

  removeNoteFromAccount(index: number) {
    this.accountDetails.notes.splice(index, 1);
  }

  removeContactFromAccount(index: number) {
    this.accountDetails.contacts.splice(index, 1);
  }

  open(content: any) {
    this.accountReview = new AccountReview();
    if (this.validateAccountBeforeSave()) {
      this.comparAndReview();
      this.modalService.open(content, { size: 'lg', ariaLabelledBy: 'modal-basic-title', backdrop: 'static' }).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
  }

  closeReviewModal() {
    this.modalService.dismissAll();
  }

  comparAndReview() {
    if (this.accountDetails._id != this.prevAccountDetails._id) {
      this.accountReview.entries.push(new Entry('_id', this.prevAccountDetails._id, this.accountDetails._id));
    }
    if (this.accountDetails.accountName != this.prevAccountDetails.accountName) {
      this.accountReview.entries.push(new Entry('Account Name', this.prevAccountDetails.accountName, this.accountDetails.accountName));
    }
    if (this.accountDetails.address != this.prevAccountDetails.address) {
      this.accountReview.entries.push(new Entry('Address', this.prevAccountDetails.address, this.accountDetails.address));
    }
    if (this.accountDetails.ceo != this.prevAccountDetails.ceo) {
      this.accountReview.entries.push(new Entry('CEO', this.prevAccountDetails.ceo, this.accountDetails.ceo));
    }
    if (this.accountDetails.employeeCount != this.prevAccountDetails.employeeCount) {
      this.accountReview.entries.push(new Entry('Employee Count', this.prevAccountDetails.employeeCount, this.accountDetails.employeeCount));
    }
    if (this.accountDetails.url != this.prevAccountDetails.url) {
      this.accountReview.entries.push(new Entry('URL', this.prevAccountDetails.url, this.accountDetails.url));
    }
    /** Comparing all Contacts in Account*/
    this.accountDetails.contacts.forEach(eachCurrContact => {
      this.prevAccountDetails.contacts.forEach(eachPrevContact => {
        if (eachCurrContact._id === eachPrevContact._id) {
          this.compareAndReviewContact(eachPrevContact, eachCurrContact);
        }
      });
      /** Finding the new contacts added */
      if (!eachCurrContact._id) {
        this.accountReview.addedContacts.push(eachCurrContact);
      }
    });
    /** Comparing all Notes in Account*/
    this.accountDetails.notes.forEach(eachCurrNote => {
      this.prevAccountDetails.notes.forEach(eachPrevNote => {
        if (eachCurrNote._id === eachPrevNote._id) {
          this.compareAndReviewNotes(eachPrevNote, eachCurrNote);
        }
      });
      /** Finding the new contacts added */
      if (!eachCurrNote._id) {
        this.accountReview.addedNotes.push(eachCurrNote);
      }
    });
    /** Find removed Contacts from Account */
    let removedContacts: Contact[] = <Contact[]>this.prevAccountDetails.contacts.filter(({ _id: id1 }) => !this.accountDetails.contacts.some(({ _id: id2 }) => id2 === id1));
    this.accountReview.removedContacts.push(...removedContacts);

    /** Find removed Notes from Account */
    let removedNotes: Note[] = <Note[]>this.prevAccountDetails.notes.filter(({ _id: id1 }) => !this.accountDetails.notes.some(({ _id: id2 }) => id2 === id1));
    this.accountReview.removedNotes.push(...removedNotes);
  }

  compareAndReviewContact(prevContact: Contact, currContact: Contact) {
    let contactReview = new ContactReview();
    let isAnyReviewAdded: boolean = false;
    if (prevContact._id != currContact._id) {
      contactReview.entries.push(new Entry('_id', prevContact._id, currContact._id))
      isAnyReviewAdded = true;
    }
    if (prevContact.email != currContact.email) {
      contactReview.entries.push(new Entry('Email', prevContact.email, currContact.email))
      isAnyReviewAdded = true;
    }
    if (prevContact.name != currContact.name) {
      contactReview.entries.push(new Entry('Name', prevContact.name, currContact.name))
      isAnyReviewAdded = true;
    }
    if (prevContact.phone != currContact.phone) {
      contactReview.entries.push(new Entry('Phone', prevContact.phone, currContact.phone))
      isAnyReviewAdded = true;
    }
    if (prevContact.primaryContact != currContact.primaryContact) {
      contactReview.entries.push(new Entry('PrimaryContact', prevContact.primaryContact, currContact.primaryContact))
      isAnyReviewAdded = true;
    }
    if (isAnyReviewAdded) {
      this.accountReview.contactReviews.push(contactReview);
    }
  }

  compareAndReviewNotes(prevNote: Note, currNote: Note) {
    let noteReview = new NoteReview();
    let isAnyReviewAdded: boolean = false;
    if (prevNote._id != currNote._id) {
      noteReview.entries.push(new Entry('_id', prevNote._id, currNote._id))
      isAnyReviewAdded = true;
    }
    if (prevNote.note != currNote.note) {
      noteReview.entries.push(new Entry('Note', prevNote.note, currNote.note))
      isAnyReviewAdded = true;
    }
    if (isAnyReviewAdded) {
      this.accountReview.noteReviews.push(noteReview);
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  saveAccountDetails() {
    this.spinner.show();
    this.closeReviewModal();
    this.homeService.updateAccount(this.accountDetails).subscribe((data) => {
      this.spinner.hide();
      this.toastr.success(`Account Details for updated successfully.}.`, "Success");
      this.router.navigateByUrl('/home');
    }, (error) => {
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    });
  }

  validateAccountBeforeSave() {
    let fields: string[] = [];
    let isValidAccount: boolean = true;
    if (!this.accountDetails.accountName && this.accountDetails.accountName == '') {
      fields.push('Madatory fields require');
    } else if (!this.accountDetails.accountName.match("^[a-zA-Z0-9]*$")) {
      fields.push('Account Name must contain alphanumric');
    }
    if (!this.accountDetails.address && this.accountDetails.address == '') {
      fields.push('Madatory fields require');
    } else if (!this.accountDetails.address.match("^[a-zA-Z0-9]*$")) {
      fields.push('Account Name must contain alphanumric');
    }
    if (this.accountDetails.contacts && this.accountDetails.contacts.length > 0) {
      let primaryContacts: Contact[] = this.accountDetails.contacts.filter(eachContact => {
        return eachContact.primaryContact == true
      })
      if (primaryContacts.length > 1 || primaryContacts.length == 0) {
        fields.push('Please select one primary contact.');
      }
      this.accountDetails.contacts.forEach(eachContact => {
        fields.push(...this.validateContactBeforeSave(eachContact));
      })
    } else {
      fields.push('There is no contacts added for this account');
    }
    this.fieldsSet = [...new Set(fields)];
    if (this.fieldsSet.length > 0) {
      isValidAccount = false;
      this.toastr.warning(this.fieldsSet.join("</br>"), '', { enableHtml: true });
    }
    return isValidAccount;
  }

  validateContactBeforeSave(contact: Contact) {
    let isValidContact: boolean = true;
    let fields: string[] = [];
    if (!contact.name && contact.name == '') {
      fields.push('Contact madatory fields require');
      isValidContact = false;
    } else if (!contact.name.match("^[a-zA-Z0-9]*$")) {
      fields.push('Contact Name must not contain alphanumric');
      isValidContact = false;
    }
    if (!contact.email && contact.email == '') {
      fields.push('Contact madatory fields require');
      isValidContact = false;
    } else if (!contact.email.toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      )) {
      fields.push('Contact email is not valid.');
      isValidContact = false;
    }
    if (!contact.phone && contact.phone != 0) {
      fields.push('Contact madatory fields require');
      isValidContact = false;
    }
    return fields;
  }
}
