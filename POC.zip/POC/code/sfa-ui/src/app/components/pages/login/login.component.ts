import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  errorMessage: string;
  public username: string = '';
  public password: string = '';
  isDisabled: boolean = true;

  constructor(private authenticationService: AuthenticationService,
    private router: Router,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private formbuilder: FormBuilder) { }

  ngOnInit(): void {
  }

  login() {
    this.spinner.show();
    this.authenticationService.login(this.username, this.password).subscribe(data => {
      localStorage.setItem('user', JSON.stringify(data));
      this.toastr.success(`Welcome ! ${this.username}.`, "Success")
      this.spinner.hide();
      this.router.navigate(["/home"]);
    }, (error) => {
      this.spinner.hide();
      this.authenticationService.handleUnauthorizeError(error);
    });
  }


}
