import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/User';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private authenticationService:AuthenticationService, private router:Router, private toastr:ToastrService) { }

  loggedInUser:User;

  ngOnInit(): void {
    this.loggedInUser = this.authenticationService.fetchUserDetailsFromLocalStorage();
    console.log(this.loggedInUser);
  }

  public logout(){
    this.authenticationService.logout();
    this.toastr.success(`User ${this.loggedInUser.userName} logged out succesfully.`,"Success")
    this.router.navigate(["/login"]);
  }

}
