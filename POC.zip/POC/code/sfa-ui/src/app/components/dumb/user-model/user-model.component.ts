import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-model',
  templateUrl: './user-model.component.html',
  styleUrls: ['./user-model.component.css']
})
export class UserModelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
