package com.sfa.tatamotors.repository;



import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.sfa.tatamotors.entities.AccountEntity;

@Repository
public interface AccountRepository extends MongoRepository<AccountEntity, String>{
	
	public List<AccountEntity> findByAccountName(String accountId);
	
}
