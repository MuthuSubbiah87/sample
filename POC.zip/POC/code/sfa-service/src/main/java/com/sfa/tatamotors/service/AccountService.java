package com.sfa.tatamotors.service;

import java.util.List;

import com.sfa.tatamotors.entities.AccountEntity;

public interface AccountService {
	
	public List<AccountEntity> fetchAllAccounts();
	
	public AccountEntity findByAccountId(String accountId);
	
	public AccountEntity saveAccount(AccountEntity accountEntity);
	
	public void updateAccount(AccountEntity accountEntity);
	
	public List<AccountEntity> searchAccount(String accountName);
	
	public void deleteAccount(String accountId);

}
