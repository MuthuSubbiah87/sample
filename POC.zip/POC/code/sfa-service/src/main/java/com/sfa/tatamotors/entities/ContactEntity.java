package com.sfa.tatamotors.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;



@Document("contacts")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactEntity {
	
	@Id
	@JsonInclude(Include.NON_NULL)
	private String _id;
	
	@Field
	private String accountId;
	
	@Field
	private String name;
	
	@Field
	private String email;
	
	@Field
	private String phone;
	
	@Field
	private boolean isPrimaryContact;
	/**
	 * @return the _id
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String get_id() {
		return _id;
	}
	/**
	 * @param _id the _id to set
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void set_id(String _id) {
		this._id = _id;
	}
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return the isPrimaryContact
	 */
	public boolean isPrimaryContact() {
		return isPrimaryContact;
	}
	/**
	 * @param isPrimaryContact the isPrimaryContact to set
	 */
	public void setPrimaryContact(boolean isPrimaryContact) {
		this.isPrimaryContact = isPrimaryContact;
	}
	
	

}
