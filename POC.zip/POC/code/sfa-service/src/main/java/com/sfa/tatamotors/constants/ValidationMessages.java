package com.sfa.tatamotors.constants;

public class ValidationMessages {

	// Request Validations
	
	//User
	public static final String  REQUEST_VALIDATION_MANDATORY_USER_ID = "User Id is mandatory";
	public static final String  REQUEST_VALIDATION_MANDATORY_FIRST_NAME = "Firstname is mandatory";
	public static final String  REQUEST_VALIDATION_MANDATORY_LAST_NAME = "Lastname is mandatory";
	public static final String  REQUEST_VALIDATION_MANDATORY_ROLE = "Role is mandatory";
	public static final String  REQUEST_VALIDATION_MANDATORY_EMAIL = "Email is mandatory";
	public static final String  REQUEST_VALIDATION_INVALID_EMAIL = "Invalid Email";
	public static final String  REQUEST_VALIDATION_MANDATORY_PASSWORD = "Password is mandatory";
	public static final String  REQUEST_VALIDATION_MANDATORY_USERNAME = "Username is mandatory";
	
	
	
	
	
}