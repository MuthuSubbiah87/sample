package com.sfa.tatamotors.utils;

import com.google.gson.Gson;
import com.sfa.tatamotors.entities.AccountEntity;

public class Test {

	public static void main(String[] args) {
		Gson gson = new Gson();
		

		System.out.println(gson.toJson(new AccountEntity()));
	}

}
