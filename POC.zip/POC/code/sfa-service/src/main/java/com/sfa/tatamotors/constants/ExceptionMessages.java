package com.sfa.tatamotors.constants;

public class ExceptionMessages {
	
	//User
	public static final String EXCEPTION_MESSAGE_USER_NOT_FOUND = "User not found with id: ";
	public static final String EXCEPTION_MESSAGE_USER_NAME_NOT_FOUND = "User not found with name: ";
	
	//Accounts
	public static final String EXCEPTION_MESSAGE_ACCOUNT_ID_NOT_FOUND = "Account not found with id: ";
	public static final String EXCEPTION_MESSAGE_ACCOUNT_NOT_SAVED_WITH_NOTES_CONTACTS = "Account detailes saved without contacts and notes details.";

}
