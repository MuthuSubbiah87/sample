package com.sfa.tatamotors.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.websocket.server.PathParam;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sfa.tatamotors.constants.LoggingConstants;
import com.sfa.tatamotors.constants.ResponseMessages;
import com.sfa.tatamotors.constants.ValidationMessages;
import com.sfa.tatamotors.entities.UserEntity;
import com.sfa.tatamotors.service.UserService;
import com.sfa.tatamotors.utils.LoggingUtil;

@RestController
@RequestMapping("/api/user")
@Validated
public class UserController {
	
	private static final Logger LOGGER = LogManager.getLogger(UserController.class);
	
	@Autowired
	UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@GetMapping("/login")
	public UserEntity login(@RequestHeader(value="username") String userName) {
		return userService.findByUsername(userName);
	}
	
	/**
	 * @param id
	 * @return
	 */
	@GetMapping("/{id}")
	public UserEntity fetchUser(@PathVariable(value = "id") @NotNull(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_USER_ID) String id){
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER, LoggingUtil.logRequestDetails(id));
		return userService.findUser(id);
	}
	
	/**
	 * @param user
	 * @return
	 */
	@PutMapping("/save")
	public void saveUser(@Valid @RequestBody UserEntity userEntity){
		userEntity.setPassword(bCryptPasswordEncoder.encode(userEntity.getPassword()));
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER,LoggingUtil.logRequestDetails(userEntity.toString()));
		userService.saveUser(userEntity);
		//return ResponseMessages.USER_SAVED_SUCCESSFULLY;
	}
	
	/**
	 * @param user
	 * @return
	 */
	@PostMapping("/update")
	public String updateUser(@Valid @RequestBody UserEntity userEntity){
		userEntity.setPassword(bCryptPasswordEncoder.encode(userEntity.getPassword()));
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER , LoggingUtil.logRequestDetails(userEntity.toString()));
		userService.updateUser(userEntity);
		return ResponseMessages.USER_UPDATED_SUCCESSFULLY;
	}
	
	/**
	 * @param firstName
	 * @return
	 */
	@GetMapping("/findByFirstName")
	public List<UserEntity> findByFirstName(@PathParam("firstName") @NotNull(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_FIRST_NAME) String firstName){
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER,LoggingUtil.logRequestDetails(firstName));
		return userService.findByFirstName(firstName);
	}
	
	/**
	 * @param user
	 * @return
	 */
	@PostMapping("/find")
	public List<UserEntity> findUsersBy(@RequestBody UserEntity user){
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER + LoggingUtil.logRequestDetails(user.toString()));
		return userService.findUsersBy(user);
	}
	
	/**
	 * @param user
	 * @return
	 */
	@GetMapping("/users")
	public List<UserEntity> findAllUsers(){
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER + LoggingUtil.logRequestDetails(""));
		return userService.fetchAllUsers();
	}
	
	/**
	 * @param user
	 * @return
	 */
	@DeleteMapping("/delete/{userId}")
	public void deleteUser(@PathVariable(value = "userId") String userId){
		LOGGER.info(LoggingConstants.RECEIVED_REQUEST_CONTROLLER + LoggingUtil.logRequestDetails(""));
		userService.deleteUser(userId);
	}
	

}
