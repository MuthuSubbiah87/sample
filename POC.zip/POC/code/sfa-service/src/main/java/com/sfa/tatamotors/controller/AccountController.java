package com.sfa.tatamotors.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sfa.tatamotors.entities.AccountEntity;
import com.sfa.tatamotors.service.AccountService;
import com.sfa.tatamotors.service.ContactService;
import com.sfa.tatamotors.service.NoteService;

@RestController
@RequestMapping("/api/account")
@Validated
public class AccountController {
	
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	ContactService contactService;
	
	@Autowired
	NoteService noteService;

	@GetMapping(value="/all")
	public List<AccountEntity> fetchAccounts() {
		return accountService.fetchAllAccounts();
	}
	
	@PostMapping(value="/update")
	public void updateAccount(@RequestBody AccountEntity accountEntity) {
		accountService.updateAccount(accountEntity);
	}
	
	
	@DeleteMapping(value="/delete/{accoundId}")
	public void deleteAccount(@PathVariable(value = "accoundId") String accoundId) {
		accountService.deleteAccount(accoundId);
	}
	
	@PutMapping(value="/add")
	public AccountEntity addAccount(@RequestBody AccountEntity accountEntity) {
		return accountService.saveAccount(accountEntity);
	}
	
	
	@GetMapping(value="/search")
	public List<AccountEntity> searchAccount(@RequestBody AccountEntity accountEntity) {
		return accountService.searchAccount(accountEntity.getAccountName());
	}
	
	@GetMapping(value="/{accoundId}")
	public AccountEntity searchAccountById(@PathVariable(value = "accoundId") String accoundId) {
		return accountService.findByAccountId(accoundId);
	}

}
