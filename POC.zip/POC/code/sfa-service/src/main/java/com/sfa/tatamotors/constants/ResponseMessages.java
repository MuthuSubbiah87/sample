package com.sfa.tatamotors.constants;

public class ResponseMessages {
	
	public static final String USER_SAVED_SUCCESSFULLY = "User saved successfully.";
	
	public static final String USER_UPDATED_SUCCESSFULLY = "User updated successfully.";

}
