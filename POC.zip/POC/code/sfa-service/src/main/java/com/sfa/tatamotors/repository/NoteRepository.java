package com.sfa.tatamotors.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.sfa.tatamotors.entities.NoteEntity;

@Repository
public interface NoteRepository extends MongoRepository<NoteEntity, String>{
	
	public List<NoteEntity> findByAccountIdIn(List<String> accountIds);
	
	public List<NoteEntity> findBy_idNotIn(List<String> ids);
	
	public List<NoteEntity> findByAccountId(String accountId);
	
	public void deleteByAccountId(String accountId);
	
	
	
}
