package com.sfa.tatamotors.repository;

import java.util.List;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.sfa.tatamotors.entities.UserEntity;

@Repository
public interface UserRepository extends MongoRepository<UserEntity, String>{
	
	@Query("{'firstName':?0}")
	public List<UserEntity> findByFirstname(String firstName);
	
	public UserEntity findByUserName(String userName);

	
}
