package com.sfa.tatamotors.utils;

public class LoggingUtil {
	
	public static String logRequestDetails(String...strings) {
		return String.join(", ", strings);
	}

}
