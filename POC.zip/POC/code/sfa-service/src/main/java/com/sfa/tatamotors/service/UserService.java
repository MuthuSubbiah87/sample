package com.sfa.tatamotors.service;

import java.util.List;

import com.sfa.tatamotors.entities.UserEntity;

public interface UserService {
	
	public UserEntity findUser(String id);
	
	public void saveUser(UserEntity user);
	
	public List<UserEntity> findByFirstName(String firstName);

	public List<UserEntity> findUsersBy(UserEntity user);
	
	public UserEntity findByUsername(String username);
	
	public List<UserEntity> fetchAllUsers();
	
	public void updateUser(UserEntity user);
	
	public void deleteUser(String userId);

}
