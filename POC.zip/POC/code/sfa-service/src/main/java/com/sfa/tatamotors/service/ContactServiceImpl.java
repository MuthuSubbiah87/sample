package com.sfa.tatamotors.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.tatamotors.entities.ContactEntity;
import com.sfa.tatamotors.repository.ContactRepository;

@Service
public class ContactServiceImpl implements ContactService{
	
	private static final Logger LOGGER = LogManager.getLogger(ContactServiceImpl.class);
	
	@Autowired
	private ContactRepository contactRepository;

	
	/**
	 * @param note
	 */
	public void saveContact(List<ContactEntity> contacts) {
		contactRepository.insert(contacts);
	}
	
	/**
	 * @param user
	 */
	public void updateContact(List<ContactEntity> contacts) {
		contactRepository.saveAll(contacts);
	}
	
	/**
	 * @param note
	 */
	public void deleteContact(List<ContactEntity> contacts) {
		contactRepository.deleteAll(contacts);
	}
	

}
