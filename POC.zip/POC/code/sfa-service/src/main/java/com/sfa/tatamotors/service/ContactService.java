package com.sfa.tatamotors.service;

import java.util.List;

import com.sfa.tatamotors.entities.ContactEntity;

public interface ContactService {
	
	public void saveContact(List<ContactEntity> contacts);
	
	public void updateContact(List<ContactEntity> contacts);
	
	public void deleteContact(List<ContactEntity> contacts);

}
