package com.sfa.tatamotors.service;

import java.util.List;

import com.sfa.tatamotors.entities.NoteEntity;

public interface NoteService {
	
	public void saveNote(List<NoteEntity> notes);
	
	public void updateNote(List<NoteEntity> notes);
	
	public void deleteNote(List<NoteEntity> notes);

}
