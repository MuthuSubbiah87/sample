package com.sfa.tatamotors.utils;

import java.util.ArrayList;
import java.util.Collection;

public class SfaUtil {
	
	public static <T> Collection<T> iterableToCollection(Iterable<T> iterable) {
		  Collection<T> collection = new ArrayList<>();
		  iterable.forEach(collection::add);
		  return collection;
		}

}
