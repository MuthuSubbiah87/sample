package com.sfa.tatamotors.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.tatamotors.entities.NoteEntity;
import com.sfa.tatamotors.repository.NoteRepository;

@Service
public class NoteServiceImpl implements NoteService{
	
	private static final Logger LOGGER = LogManager.getLogger(NoteServiceImpl.class);
	
	@Autowired
	private NoteRepository noteRepository;
	
	/**
	 * @param note
	 */
	public void saveNote(List<NoteEntity> notes) {
		noteRepository.insert(notes);
	}
	
	/**
	 * @param user
	 */
	public void updateNote(List<NoteEntity> notes) {
		noteRepository.saveAll(notes);
	}
	
	/**
	 * @param note
	 */
	public void deleteNote(List<NoteEntity> notes) {
		noteRepository.deleteAll(notes);
	}

}
