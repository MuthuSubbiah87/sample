package com.sfa.tatamotors.service;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sfa.tatamotors.constants.ExceptionMessages;
import com.sfa.tatamotors.entities.UserEntity;
import com.sfa.tatamotors.exception.UserNotFoundException;
import com.sfa.tatamotors.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService, UserDetailsService{
	
	private static final Logger LOGGER = LogManager.getLogger(UserServiceImpl.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	/**
	 *
	 */
	public UserEntity findUser(String id) {
		return userRepository.findById(id).orElseThrow(()->new UserNotFoundException(ExceptionMessages.EXCEPTION_MESSAGE_USER_NOT_FOUND+id));
	}
	
	/**
	 * @param user
	 */
	public void saveUser(UserEntity user) {
		UserEntity savedUser = userRepository.insert(user);
		LOGGER.info("User added successfully. ID={}",savedUser.get_id());
	}
	
	/**
	 * @param user
	 */
	public void updateUser(UserEntity user) {
		UserEntity savedUser = userRepository.save(user);
		LOGGER.info("User added successfully. ID={}",savedUser.get_id());
	}
	
	/**
	 * @param user
	 */
	public void deleteUser(String userId) {
		userRepository.deleteById(userId);
		LOGGER.info("User deleted successfully. ID={}",userId);
	}
	
	/**
	 * @param id
	 * @param email
	 * @return
	 */
	public List<UserEntity> findByFirstName(String firstName) {
		return userRepository.findByFirstname(firstName);
	}
	
	/**
	 * @param userFilter
	 * @return
	 */
	public List<UserEntity> findUsersBy(UserEntity user){ 
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(user.getEmail()));
		return mongoTemplate.find(getSearchQuery(user), UserEntity.class);
	}
	
	/**
	 * @param user
	 * @return
	 */
	private Query getSearchQuery(UserEntity user) {
		Query query = new Query();
		if (user.getEmail()!=null) {
			query.addCriteria(Criteria.where("email").is(user.getEmail()));
		}
		if(user.getFirstName()!=null) {
			query.addCriteria(Criteria.where("firstName").is(user.getFirstName()));
		}
		if(user.getLastName()!=null) {
			query.addCriteria(Criteria.where("lastName").is(user.getLastName()));
		}
		if(user.getRole()!=null) {
			query.addCriteria(Criteria.where("role").is(user.getRole()));
		}
		return query;
	}

	/**
	 * @param username
	 * @return
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserEntity userEntity = userRepository.findByUserName(username);
		SFAUserDetails sFAUserDetails = null;
		if (userEntity!=null) {
			sFAUserDetails = new SFAUserDetails();
			sFAUserDetails.setUserEntity(userEntity);
		}else{
			new UsernameNotFoundException(ExceptionMessages.EXCEPTION_MESSAGE_USER_NAME_NOT_FOUND+username);
		}
		return sFAUserDetails;
	}
	
	/**
	 *@param username
	 */
	public UserEntity findByUsername(String username) {
		UserEntity user = userRepository.findByUserName(username);
		user.setPassword("****");
		return user;
	}
	
	/**
	 *
	 */
	public List<UserEntity> fetchAllUsers() {
		return userRepository.findAll().stream().map(this::removePassword).collect(Collectors.toList());
	}
	
	private UserEntity removePassword(UserEntity user) {
		user.setPassword("**");
		return user;
	}

}
