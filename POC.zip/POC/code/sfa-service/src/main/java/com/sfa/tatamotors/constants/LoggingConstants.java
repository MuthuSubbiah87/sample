package com.sfa.tatamotors.constants;

public class LoggingConstants {
	
	public static final String RECEIVED_REQUEST_CONTROLLER = "#Received Request#### - ";
	
}