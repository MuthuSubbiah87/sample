package com.sfa.tatamotors.entities;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.sfa.tatamotors.constants.ValidationMessages;

@Document("users")
public class UserEntity {
	
	@Id
	private String _id;
	
	@NotBlank(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_FIRST_NAME)
	@Field
	private String firstName;
	
	@NotBlank(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_LAST_NAME)
	@Field
	private String lastName;
	
	@NotBlank(message =  ValidationMessages.REQUEST_VALIDATION_MANDATORY_EMAIL)
	@Email(message = ValidationMessages.REQUEST_VALIDATION_INVALID_EMAIL)
	@Field
	private String email;
	
	@NotBlank(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_ROLE)
	@Field
	private String role;
	
	@NotBlank(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_PASSWORD)
	@Field
	private String password;
	
	@NotBlank(message = ValidationMessages.REQUEST_VALIDATION_MANDATORY_USERNAME)
	@Field
	private String userName;
	
	@Field
	private boolean isActive;

	public UserEntity(@NotBlank(message = "Firstname is mandatory") String firstName,
			@NotBlank(message = "Lastname is mandatory") String lastName,
			@NotBlank(message = "Email is mandatory") @Email(message = "Invalid Email") String email,
			@NotBlank(message = "Role is mandatory") String role) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.role = role;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "UserEntity [_id=" + _id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", role=" + role + "]";
	}
	
	

}
