package com.sfa.tatamotors.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	/**
	 * @param userNotFoundException
	 * @param webRequest
	 * @return
	 */
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<?> handleUserNotFoundException(UserNotFoundException userNotFoundException, WebRequest webRequest){
		ErrorDetails errorDetails = new ErrorDetails(404,userNotFoundException.getMessage());
		return new ResponseEntity(errorDetails, HttpStatus.NOT_FOUND);
	}

	/**
	 * @param exception
	 * @param webRequest
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleGenericException(Exception exception, WebRequest webRequest){
		ErrorDetails errorDetails = new ErrorDetails(500,exception.getMessage());
		return new ResponseEntity(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
