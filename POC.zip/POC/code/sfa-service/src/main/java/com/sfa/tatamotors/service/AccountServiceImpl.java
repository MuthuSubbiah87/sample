package com.sfa.tatamotors.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.tatamotors.constants.ExceptionMessages;
import com.sfa.tatamotors.entities.AccountEntity;
import com.sfa.tatamotors.entities.ContactEntity;
import com.sfa.tatamotors.entities.NoteEntity;
import com.sfa.tatamotors.exception.AccountNotFoundException;
import com.sfa.tatamotors.repository.AccountRepository;
import com.sfa.tatamotors.repository.ContactRepository;
import com.sfa.tatamotors.repository.NoteRepository;

@Service
public class AccountServiceImpl implements AccountService{
	
	private static final Logger LOGGER = LogManager.getLogger(AccountServiceImpl.class);
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private NoteRepository noteRepository;
	
	@Autowired
	private ContactRepository contactRepository;
	
	
	public List<AccountEntity> fetchAllAccounts(){
		return addContactAndNotesDetails(accountRepository.findAll());
		
	}
	
	/**
	 *@param note accountId
	 */
	public AccountEntity findByAccountId(String accountId){
		AccountEntity accountEntity = null;
		Optional<AccountEntity> accountEntityOpt = accountRepository.findById(accountId);
		if (accountEntityOpt.isPresent()) {
			accountEntity = addContactAndNotesDetails(accountEntityOpt.get());
		} else {
			throw new AccountNotFoundException(ExceptionMessages.EXCEPTION_MESSAGE_ACCOUNT_ID_NOT_FOUND+accountId);
		}
		return accountEntity;
	}
	
	
	/**
	 * @param note
	 */
	public AccountEntity saveAccount(AccountEntity accountEntity) {
		AccountEntity accountEntityToSave = getAccountDetailsToSave(accountEntity);
		AccountEntity accountEntitySaved = accountRepository.insert(accountEntityToSave);
		LOGGER.info("Account details saved successfully. ID={}", accountEntitySaved.get_id());
		/*if (accountEntitySaved.get_id()!=null) {
			noteRepository.insert(accountEntity.getNotes().stream().map(eachNote->{
				eachNote.setAccountId(accountEntitySaved.get_id());
				return eachNote;
			}).collect(Collectors.toList()));
			contactRepository.insert(accountEntity.getContacts().stream().map(eachContact->{
				eachContact.setAccountId(accountEntitySaved.get_id());
				return eachContact;
			}).collect(Collectors.toList()));
			LOGGER.info("Notes and Contacts for account details are saved successfully. ID={}", accountEntitySaved.get_id());
		}else{
			LOGGER.warn(ExceptionMessages.EXCEPTION_MESSAGE_ACCOUNT_NOT_SAVED_WITH_NOTES_CONTACTS);
		}*/
		return accountEntitySaved;
	}
	
	/**
	 * @param user
	 */
	public void updateAccount(AccountEntity accountEntity) {
		AccountEntity accountEntityToSave = getAccountDetailsToSave(accountEntity);
		accountRepository.save(accountEntityToSave);
		LOGGER.info("Account ID={} updated succesfully.", accountEntityToSave.get_id());
		noteRepository.saveAll(accountEntity.getNotes());
		LOGGER.info("Notes updated for account ID={} succesfully.", accountEntityToSave.get_id());
		contactRepository.saveAll(accountEntity.getContacts());
		LOGGER.info("Contacts updated for account ID={} succesfully.", accountEntityToSave.get_id());
		deleteRemovedContacts(accountEntity);
		deleteRemovedNotes(accountEntity);
	}
	
	private void deleteRemovedContacts(AccountEntity accountEntity){
		List<String> contactIds = accountEntity.getContacts().stream().map(eachContact->{
			return eachContact.get_id();
		}).collect(Collectors.toList());
		List<ContactEntity> contactIdsToRemove = contactRepository.findBy_idNotIn(contactIds)
				.stream().filter(eachContact->eachContact.getAccountId().equals(accountEntity.get_id())).collect(Collectors.toList());
		LOGGER.info("Removing contacts.", contactIdsToRemove);
		contactRepository.deleteAll(contactIdsToRemove);
	}
	
	private void deleteRemovedNotes(AccountEntity accountEntity){
		List<String> noteIds = accountEntity.getNotes().stream().map(eachNote->{
			return eachNote.get_id();
		}).collect(Collectors.toList());
		List<NoteEntity> noteIdsToRemove = noteRepository.findBy_idNotIn(noteIds)
				.stream().filter(eachContact->eachContact.getAccountId().equals(accountEntity.get_id())).collect(Collectors.toList());
		LOGGER.info("Removing notes.", noteIdsToRemove);
		noteRepository.deleteAll(noteIdsToRemove);
	}
	
	
	
	/**
	 * @param note
	 */
	public List<AccountEntity> searchAccount(String accountName) {
		return addContactAndNotesDetails(accountRepository.findByAccountName(accountName));
	}
	
	/**
	 * @param note
	 */
	public void deleteAccount(String accountId) {
		accountRepository.deleteById(accountId);
		LOGGER.info("Account deleted for ID={}", accountId);
		noteRepository.deleteByAccountId(accountId);
		LOGGER.info("All notes deleted for Account ID={}", accountId);
		contactRepository.deleteByAccountId(accountId);
		LOGGER.info("All contacts deleted for Account ID={}", accountId);
		
	}
	
	/**
	 * @param accountEntities
	 * @return
	 */
	private List<AccountEntity> addContactAndNotesDetails(List<AccountEntity> accountEntities){
		return accountEntities.stream().map(eachAccountEntity->{
			eachAccountEntity.setContacts(contactRepository.findByAccountId(eachAccountEntity.get_id()));
			eachAccountEntity.setNotes(noteRepository.findByAccountId(eachAccountEntity.get_id()));
			return eachAccountEntity;
		}).collect(Collectors.toList());
	}
	
	/**
	 * @param AccountEntity
	 * @return
	 */
	private AccountEntity addContactAndNotesDetails(AccountEntity accountEntity){
		accountEntity.setContacts(contactRepository.findByAccountId(accountEntity.get_id()));
		accountEntity.setNotes(noteRepository.findByAccountId(accountEntity.get_id()));
		return accountEntity;
	}
	
	/**
	 * @param accountEntities
	 * @return
	 */
	private List<String> collectAccountIds(List<AccountEntity> accountEntities){
		return accountEntities.stream().map(eachAccount->eachAccount.get_id()).collect(Collectors.toList());
	}
	
	private AccountEntity getAccountDetailsToSave(AccountEntity accountEntity) {
		AccountEntity accountEntityToSave = new AccountEntity();
		accountEntityToSave.set_id(accountEntity.get_id());
		accountEntityToSave.setAccountName(accountEntity.getAccountName());
		accountEntityToSave.setAddress(accountEntity.getAddress());
		accountEntityToSave.setCeo(accountEntity.getCeo());
		accountEntityToSave.setUrl(accountEntity.getUrl());
		accountEntityToSave.setEmployeeCount(accountEntity.getEmployeeCount());
		return accountEntityToSave;
		
	}
	

}
