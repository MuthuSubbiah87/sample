package com.sfa.tatamotors.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.sfa.tatamotors.entities.ContactEntity;
import com.sfa.tatamotors.entities.NoteEntity;

@Repository
public interface ContactRepository extends MongoRepository<ContactEntity, String>{
	
	public List<ContactEntity> findByAccountIdIn(List<String> accountIds);
	
	public List<ContactEntity> findBy_idNotIn(List<String> ids);
	
	public List<ContactEntity> findByAccountId(String accountId);
	
	public void deleteByAccountId(String accountId);
	
}
