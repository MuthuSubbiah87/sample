package com.sfa.tatamotors.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sfa.tatamotors.entities.UserEntity;
import com.sfa.tatamotors.exception.UserNotFoundException;
import com.sfa.tatamotors.service.UserService;


@SpringBootTest
public class UserServiceTest {
	
	@Autowired
	UserService userService;
	
	@Test
	@DisplayName("Should save user details into database.")
	public void saveUserTest() {
		userService.saveUser(new UserEntity("Test_FirstName","Test_LastName","Test@Email.com","Test_Role"));
		List<UserEntity> users = userService.findByFirstName("Test_FirstName");
		assertTrue(users.size()>0);
	}
	
	@Test
	@DisplayName("Should throw UserNotFoundException when given ID is not present.")
	public void findUserNotFound() {
		try {
		UserEntity user = userService.findUser("123");
		}catch(UserNotFoundException e) {
			assertTrue(true);
		}
	}
	
	@Test
	@DisplayName("Should return the user for given ID")
	public void findUser() {
		try {
		UserEntity user = userService.findUser("61f3ef685a39cc4e1e917b8e");
		assertTrue(user!=null);
		}catch(UserNotFoundException e) {
			
		}
	}
}
