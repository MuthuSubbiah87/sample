package com.sfa.tatamotors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SFAApplicationTests {

	@Test
	void contextLoads() {
	}

}
