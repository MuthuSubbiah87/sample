package com.sfa.tatamotors.repository;

public class UserRepositoryTest {
	

}
