package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Other {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Singleton test = Singleton.getSingletonInstance();
		int n = 10;
		//printFibonocieSeries(10);
		//System.out.println(printFibonoceSeriesRec(n));
		//System.out.println(removeWhiteSpaces("Mu thu "));
		//System.out.println(checkPrimeNumber(Arrays.asList(new Integer[] {7})));
		//System.out.println(checkPalindrome("LIRIL"));
		//sortEmployee(Arrays.asList(new Employee[] {new Employee("Muthu",34,3), new Employee("Sarat",44,07), new Employee("Shalini",38,06)}));
		System.out.println("Factorial of " + factorialOf(6));
	}
	
	private static void printFibonocieSeries(int count) {
		int a = 0;
		int b = 1;
		int c = 1;
		System.out.println("FIBONOCEE SERIES");
		for (int i=0;i<=count;i++) {
			System.out.println(a+",");
			a=b;
			b=c;
			c=a+b;
		}
	}
	
	private static int printFibonoceSeriesRec(int count) {
		if (count<=1){
			return count;
		}
		return printFibonoceSeriesRec(count-1)+ printFibonoceSeriesRec(count-2);
	}
	
	private static String removeWhiteSpaces(String inputString) {
		char[] inputChars = inputString.toCharArray();
		StringBuilder outputStr = new StringBuilder();
		for (char eachChar: inputChars) {
			if (!Character.isWhitespace(eachChar)) {
				outputStr.append(eachChar);
			}
		}
		return outputStr.toString();
	}
	
	private static boolean checkPrimeNumber(List<Integer> list) {
		return list.stream().anyMatch(e->e%2==0);
	}
	
	private static boolean checkPalindrome(String inputString) {
		return inputString.toLowerCase().equals(new StringBuilder(inputString.toLowerCase()).reverse().toString());
	}
	
	private static void sortEmployee(List<Employee> list){
		Collections.sort(list,(emp1,emp2)->{
			return emp2.getRoleLevel()-emp1.getRoleLevel();
		});
		System.out.println(list.toString());
	}
	
	private static int factorialOf(int n) {
		if (n==1) {
			return 1;
		} else {
			return (n * factorialOf(n-1));
		}
	}

}
