package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(sum(Arrays.asList(new Integer[] {1,2,3,10})).get());
		//System.out.println(sumStrig(Arrays.asList(new String[] {"1","2","3","10"})).get());
		
		//System.out.println(String.join("", Arrays.asList(new String[] {"1","2","3","10"})));
		
		System.out.println(findSecondLargest(Arrays.asList(new Integer[] {1,2,3,10,12,1,222})));
	}
	
	private static Optional<Integer> sum(List<Integer> list){
		return list.stream().reduce((result, e)->{
			return result = result +e;
		});
	}
	
	private static Optional<String> sumStrig(List<String> list){
		return list.stream().reduce((result, e)->{
			return result = result +e;
		});
	}
	
	private static int findSecondLargest(List<Integer> list) {
		List<Integer> ulist = new ArrayList<Integer>(new HashSet<Integer>(list));
		Collections.sort(ulist,(e1,e2)->{
			return -1;
		});
		System.out.println(ulist);
		return ulist.get(1);
	}

}
