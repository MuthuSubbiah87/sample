package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class Data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			List<Object> list = Arrays.asList(1,2,2,1,3,3,3,1,1,1);
			Integer[] list = new Integer[]  {1,2,2,1,3,3,3,1,1,1,1};
			int pointer = 0;
			Map<Integer,Integer> map = new HashMap<Integer,Integer>();
			for (int i=0;i<list.length;i++) {
				int count=0;
				pointer = list[i];
				for (int j=0;j<list.length;j++) {
					if (pointer==list[j]) {
						map.put(pointer, count++ + 1);
					}
				}
			}
			map = map.entrySet().stream().sorted().collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1,e2) -> e1,HashMap::new));
			System.out.println(map);

	}

}
