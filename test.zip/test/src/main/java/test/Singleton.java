package test;

public class Singleton {
	
	private static Singleton testSingletonObj = null;
	
	private Singleton() {
		
	}
	
	public static Singleton getSingletonInstance() {
		if (testSingletonObj!=null) {
			testSingletonObj = new Singleton();
		}
		return testSingletonObj;
	}

}
