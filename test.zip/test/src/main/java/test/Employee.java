package test;

import java.util.Objects;

public class Employee {
	private Integer age;
	private Integer roleLevel;
	private String name;
	
	Employee(String name, Integer age, Integer roleLevel ){
		this.name = name;
		this.age = age;
		this.roleLevel = roleLevel;
	}
	
	@Override
	public String toString() {
		return "Employee [age=" + age + ", roleLevel=" + roleLevel + ", name=" + name + "]";
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name=name;
	}

	public Integer getRoleLevel() {
		return roleLevel;
	}

	public void setRoleLevel(Integer roleLevel) {
		this.roleLevel = roleLevel;
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, name, roleLevel);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(age, other.age) && Objects.equals(name, other.name)
				&& Objects.equals(roleLevel, other.roleLevel);
	}
	
	
}

