package test;

public class ThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable run1 = new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		};
		
		Thread thread1 = new Thread(run1);
		
	}

}



