package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ListTest {

	public static void main(String[] args) {
		LinkedList<Integer> inputList = new LinkedList<Integer>();
		inputList.add(1);
		inputList.add(2);
		inputList.add(3);
		inputList.add(3);
		//	reverseLinkedList(inputList);
		
		// Remove Duplicate using Set
		//System.out.println(removedDuplicate(Arrays.asList( new String[] {"A","B", "B" ,"C"})));
		//System.out.println(removedDuplicateObject(Arrays.asList(new Employee[] {new Employee("Muthu",34,3), new Employee("Muthu",34,3), new Employee("Sarat",44,07), new Employee("Shalini",38,06)})));
		
		Set<Integer> firstSet = new HashSet<Integer>();
		firstSet.add(1);
		firstSet.add(3);
		Set<Integer> secondSet = new HashSet<Integer>();
		secondSet.add(2);
		secondSet.add(3);
		//System.out.println(secondSet.retainAll(firstSet));
		//System.out.println(secondSet);
		
		
		//System.out.println(secondSet.containsAll(firstSet));
		
		printPyramid('M',10);
	}
	
	private static void reverseLinkedList(LinkedList<Integer> list) {
		LinkedList<Integer> output = new LinkedList<Integer>();
		list.descendingIterator().forEachRemaining(e->output.add(e));
		System.out.println(output);
		System.out.println(list.getFirst());
	}
	
	private static List<String> removedDuplicate(List<String> inputList){
		Set<String> uniqueArray = new HashSet<String>(inputList);
		return new ArrayList<String>(uniqueArray);
	}
	
	private static List<Employee> removedDuplicateObject(List<Employee> inputList){
		Set<Employee> uniqueArray = new HashSet<Employee>(inputList);
		return new ArrayList<Employee>(uniqueArray);
	}
	
	private static void printPyramid(char inputChar,int lines) {
		for(int i=lines;i>=1;i--) {
			for (int j=0;j<=lines;j++) {
				if (j%2==1) {
					System.out.print(inputChar);
				} else {
					System.out.print("  ");
				}
				
			}
			System.out.println("");
		}
	}

}
