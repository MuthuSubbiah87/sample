package com.covalent.common;

public class CovalentConstants {
	
	public static final String FILE_UPLOADED = "File Uploaded";
	
	public static final String FILE_PARSED = "File Parsed";
	
	public static final String FILE_TRANSFORMED = "File Transformed";
	
	public static final String FILE_FIXED = "File Fixed";
	
}
