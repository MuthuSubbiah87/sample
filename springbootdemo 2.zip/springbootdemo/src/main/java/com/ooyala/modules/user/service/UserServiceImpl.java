package com.ooyala.modules.user.service;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ooyala.clients.OoyalaAPI;
import com.ooyala.exceptions.HttpStatusCodeException;
import com.ooyala.modules.user.model.User;
import com.ooyala.modules.user.repository.UserRepository;

@Service
public final class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User create(User employee) {
		userRepository.save(employee);
		return null;
	}

	@Override
	public User delete(String id) {
		userRepository.delete(id);
		return null;
	}

	@Override
	public List<User> findAll() {
		List<User> employeesList = userRepository.findAll();
		OoyalaAPI ooyalaClient = new OoyalaAPI("c3ZmsyOrgYpu7AIueYnoBduEo7B1.11T4O","XKYBJjvAHCV1qL_e16Q8cEJJUSAary3dXHlXLuwX");
		try {
			Object ooyalaUsers = ooyalaClient.getRequest("players");
			System.out.println("Ooyala Users: " + ooyalaUsers);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HttpStatusCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employeesList;
	}

	@Override
	public User findById(String id) {
		userRepository.findOne(id);
		return null;
	}

	@Override
	public User update(User user) {
		userRepository.save(user);
		return null;
	}

}
