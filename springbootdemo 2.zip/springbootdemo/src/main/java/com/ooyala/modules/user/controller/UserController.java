package com.ooyala.modules.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ooyala.modules.user.model.User;
import com.ooyala.modules.user.service.UserService;

@RestController
public class UserController {

	private final UserService service;

	@Autowired
	UserController(UserService service) {
		this.service = service;
	}

	@RequestMapping("/user/list")
	public List<User> getUsers() {
		List<User> employeesList = service.findAll();
		return employeesList;
	}

	@RequestMapping("/user/create")
	public void saveUser() {
		User employee = new User();
		employee.setFirstName("Muthu");
		employee.setLastName("Subbiah");
		employee.setEmail("muthu_subbiah01@infosys.com");
		service.create(employee);
	}

	@RequestMapping("/user/delete")
	public void removeUser() {
		System.out.println("UserController: removeUser()");
		service.delete("599575c3e4eeae34c45fff8c");
	}

	@RequestMapping("/user/update")
	public void updateUser() {
		System.out.println("UserController: updateUser()");
		User employee = new User();
		employee.setId("599575c3e4eeae34c45fff8c");
		employee.setEmail("guru.gms@gmail.com");
		service.update(employee);
	}
	
	@RequestMapping("/user/find")
	public void findUser() {
		System.out.println("UserController: findUser()");
		service.findById("599575c3e4eeae34c45fff8c");
	}

}
